#include <gtk/gtk.h>


void
on_button3_supprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data);
void
on_button1_ajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button7_add_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton3_valide_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_heb_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_nut_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_n_valide_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button2_afficher_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button1_retour_clicked              (GtkButton       *button,
                                        gpointer         user_data);


void
on_button2_recherche_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_modifier_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button6_modifier_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_plus_reclamee_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

